def hello_person():
    print("hello person")